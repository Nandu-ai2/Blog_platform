import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, Edit, Trash2, Save, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { BlogPost } from "@shared/schema";

interface BlogFormData {
  title: string;
  content: string;
  tags: string;
  description: string;
}

export default function AdminPage() {
  const { toast } = useToast();
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<BlogFormData>({
    title: "",
    content: "",
    tags: "",
    description: "",
  });

  const { data: posts = [], isLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/blogs"],
  });

  const handleNewPost = () => {
    setFormData({
      title: "",
      content: "",
      tags: "",
      description: "",
    });
    setSelectedPost(null);
    setIsEditing(true);
  };

  const handleEditPost = (post: BlogPost) => {
    setFormData({
      title: post.title,
      content: post.content,
      tags: post.tags?.join(", ") || "",
      description: post.description || "",
    });
    setSelectedPost(post);
    setIsEditing(true);
  };

  const handleSavePost = async () => {
    if (!formData.title || !formData.content) {
      toast({
        title: "Validation Error",
        description: "Title and content are required",
        variant: "destructive",
      });
      return;
    }

    try {
      const postData = {
        title: formData.title,
        content: formData.content,
        description: formData.description || formData.content.substring(0, 150) + "...",
        tags: formData.tags
          .split(",")
          .map(tag => tag.trim())
          .filter(tag => tag.length > 0),
      };

      if (selectedPost) {
        // Update existing post
        await apiRequest("PATCH", `/api/blogs/${selectedPost.id}`, postData);
        toast({
          title: "Success",
          description: "Blog post updated successfully",
        });
      } else {
        // Create new post
        await apiRequest("POST", "/api/blogs", postData);
        toast({
          title: "Success",
          description: "Blog post created successfully",
        });
      }

      // Refresh the posts list
      queryClient.invalidateQueries({ queryKey: ["/api/blogs"] });
      setIsEditing(false);
      setSelectedPost(null);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save blog post",
        variant: "destructive",
      });
    }
  };

  const handleDeletePost = async (post: BlogPost) => {
    if (!confirm("Are you sure you want to delete this post?")) {
      return;
    }

    try {
      await apiRequest("DELETE", `/api/blogs/${post.id}`);
      
      toast({
        title: "Success",
        description: "Blog post deleted successfully",
      });
      
      // Refresh the posts list
      queryClient.invalidateQueries({ queryKey: ["/api/blogs"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete blog post",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-foreground mb-2">Loading...</h2>
          <p className="text-muted-foreground">Loading admin panel</p>
        </div>
      </div>
    );
  }

  if (isEditing) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-4xl mx-auto p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsEditing(false)}
                data-testid="back-to-list"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Posts
              </Button>
              <h1 className="text-2xl font-bold">
                {selectedPost ? "Edit Post" : "Create New Post"}
              </h1>
            </div>
            <Button onClick={handleSavePost} data-testid="save-post">
              <Save className="h-4 w-4 mr-2" />
              Save Post
            </Button>
          </div>

          <div className="space-y-6">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Enter blog post title"
                className="mt-1"
                data-testid="input-title"
              />
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Brief summary of the post (optional)"
                className="mt-1"
                rows={2}
                data-testid="input-description"
              />
            </div>

            <div>
              <Label htmlFor="tags">Tags</Label>
              <Input
                id="tags"
                value={formData.tags}
                onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
                placeholder="Enter tags separated by commas (e.g., React, JavaScript, Web Development)"
                className="mt-1"
                data-testid="input-tags"
              />
            </div>

            <div>
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                value={formData.content}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Write your blog post content here..."
                className="mt-1 min-h-[400px]"
                data-testid="input-content"
              />
              <p className="text-sm text-muted-foreground mt-1">
                You can use Markdown syntax for formatting
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">Admin Panel</h1>
          <Button onClick={handleNewPost} data-testid="create-new-post">
            <Plus className="h-4 w-4 mr-2" />
            Create New Post
          </Button>
        </div>

        <Tabs defaultValue="posts" className="space-y-4">
          <TabsList>
            <TabsTrigger value="posts" data-testid="tab-posts">Blog Posts</TabsTrigger>
            <TabsTrigger value="analytics" data-testid="tab-analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="posts">
            <div className="grid gap-4">
              {posts.length === 0 ? (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center py-8">
                      <h3 className="text-lg font-semibold mb-2">No blog posts yet</h3>
                      <p className="text-muted-foreground mb-4">
                        Create your first blog post to get started
                      </p>
                      <Button onClick={handleNewPost}>
                        <Plus className="h-4 w-4 mr-2" />
                        Create First Post
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                posts.map((post) => (
                  <Card key={post.id} className="relative">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <CardTitle className="text-lg">{post.title}</CardTitle>
                          <p className="text-sm text-muted-foreground">
                            {post.description || post.content.substring(0, 100) + "..."}
                          </p>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs text-muted-foreground">
                              {post.publishDate 
                                ? new Date(post.publishDate).toLocaleDateString()
                                : "Draft"}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              • {post.views || 0} views
                            </span>
                          </div>
                          {post.tags && post.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {post.tags.map((tag) => (
                                <Badge key={tag} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditPost(post)}
                            data-testid={`edit-post-${post.slug}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeletePost(post)}
                            data-testid={`delete-post-${post.slug}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle>Blog Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 border rounded-lg">
                    <h3 className="text-2xl font-bold">{posts.length}</h3>
                    <p className="text-muted-foreground">Total Posts</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <h3 className="text-2xl font-bold">
                      {posts.reduce((total, post) => total + (post.views || 0), 0)}
                    </h3>
                    <p className="text-muted-foreground">Total Views</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <h3 className="text-2xl font-bold">
                      {posts.filter(post => post.publishDate).length}
                    </h3>
                    <p className="text-muted-foreground">Published Posts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
import { useState, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import BlogCard from "@/components/blog-card";
import SearchFilter from "@/components/search-filter";
import Pagination from "@/components/pagination";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import type { BlogPost } from "@shared/schema";

export default function Home() {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const limit = 6;

  const buildQueryKey = useCallback(() => {
    const params = new URLSearchParams({
      page: currentPage.toString(),
      limit: limit.toString(),
    });
    
    if (searchQuery.trim()) {
      params.set("search", searchQuery.trim());
    }
    
    if (selectedTags.length > 0) {
      params.set("tags", selectedTags.join(","));
    }
    
    return `/api/blogs?${params.toString()}`;
  }, [currentPage, searchQuery, selectedTags]);

  const {
    data,
    isLoading,
    error,
    isError,
  } = useQuery({
    queryKey: [buildQueryKey()],
  });

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    setCurrentPage(1);
  }, []);

  const handleTagFilter = useCallback((tags: string[]) => {
    setSelectedTags(tags);
    setCurrentPage(1);
  }, []);

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  if (isError) {
    return (
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Alert variant="destructive" data-testid="error-alert">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Failed to load blog posts. {error instanceof Error ? error.message : "Please try again later."}
          </AlertDescription>
        </Alert>
      </main>
    );
  }

  const posts = (data as any)?.posts || [];
  const totalPages = (data as any)?.totalPages || 0;
  const total = (data as any)?.total || 0;

  return (
    <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <section className="text-center py-12 bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl mb-12">
        <h1 className="text-4xl font-bold text-foreground mb-4" data-testid="hero-title">
          Welcome to BlogCraft
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="hero-description">
          Discover insightful articles, tutorials, and stories from our community of writers and developers.
        </p>
      </section>

      {/* Search and Filter */}
      <SearchFilter
        onSearch={handleSearch}
        onTagFilter={handleTagFilter}
        searchQuery={searchQuery}
        selectedTags={selectedTags}
      />

      {/* Results Info */}
      {(searchQuery || selectedTags.length > 0) && !isLoading && (
        <div className="my-6">
          <p className="text-muted-foreground" data-testid="search-results-info">
            {total} post{total !== 1 ? 's' : ''} found
            {searchQuery && ` for "${searchQuery}"`}
            {selectedTags.length > 0 && ` with tag${selectedTags.length > 1 ? 's' : ''}: ${selectedTags.join(', ')}`}
          </p>
        </div>
      )}

      {/* Blog Posts Grid */}
      {isLoading ? (
        <section className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 mt-8">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="space-y-4">
              <Skeleton className="aspect-video w-full rounded-xl" />
              <div className="space-y-2 p-4">
                <div className="flex gap-2">
                  <Skeleton className="h-5 w-16 rounded-full" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                </div>
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <div className="flex justify-between">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-20" />
                </div>
              </div>
            </div>
          ))}
        </section>
      ) : posts.length === 0 ? (
        <div className="text-center py-12" data-testid="no-posts">
          <div className="text-6xl text-muted-foreground/20 mb-4">
            <i className="fas fa-search"></i>
          </div>
          <h3 className="text-xl font-semibold text-foreground mb-2">No posts found</h3>
          <p className="text-muted-foreground">
            {searchQuery || selectedTags.length > 0
              ? "Try adjusting your search terms or filters"
              : "Check back later for new content"}
          </p>
        </div>
      ) : (
        <>
          <section className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 mt-8" data-testid="blog-posts-grid">
            {posts.map((post: BlogPost) => (
              <BlogCard key={post.id} post={post} />
            ))}
          </section>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-12">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={handlePageChange}
              />
            </div>
          )}
        </>
      )}

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-16 -mx-4 sm:-mx-6 lg:-mx-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-xl font-bold text-primary mb-4">
                <i className="fas fa-blog mr-2"></i>BlogCraft
              </h3>
              <p className="text-muted-foreground mb-4 max-w-md">
                A modern blog platform for developers, designers, and creators. Share your knowledge and connect with a community of passionate learners.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-twitter text-xl"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-github text-xl"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-linkedin text-xl"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Categories</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">JavaScript</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">React</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">TypeScript</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">CSS</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Web Design</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Resources</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">About</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">RSS Feed</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 BlogCraft. All rights reserved. Built with modern web technologies.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}

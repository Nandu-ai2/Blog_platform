# Blog Platform - Replit.md

## Overview

This is a full-stack blog platform built with React (frontend) and Express.js (backend), using PostgreSQL with Drizzle ORM for data persistence. The application provides a dynamic blog platform where users can view blog posts, search and filter content, and read individual articles. The platform features a modern, responsive design using shadcn/ui components and Tailwind CSS, with real-time view tracking and pagination support.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing with dynamic routes for blog posts
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming support
- **Form Handling**: React Hook Form with Zod validation resolvers

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API with endpoints for blog operations
- **Database Integration**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Request Handling**: Express middleware for JSON parsing, logging, and error handling
- **Development Tools**: Hot module replacement with Vite integration in development

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Neon serverless connection
- **ORM**: Drizzle ORM for schema definition and query building
- **Schema Design**: 
  - Blog posts table with fields for title, slug, content, tags, metadata
  - Users table for potential authentication (foundation laid)
  - Indexed fields for performance (slug, tags, publish date)
- **Database Features**: UUID primary keys, array fields for tags, automatic timestamps

### Key Features Implementation
- **Search and Filtering**: Full-text search by title/content and tag-based filtering
- **Pagination**: Server-side pagination with configurable page sizes
- **View Tracking**: Automatic view count incrementing for blog posts
- **Responsive Design**: Mobile-first design with responsive navigation
- **Performance**: Optimized queries with database indexing and React Query caching

### Development Environment
- **Build System**: Vite with TypeScript support and React Fast Refresh
- **Code Quality**: TypeScript strict mode with path aliases for clean imports
- **Development Server**: Express server with Vite middleware integration
- **Asset Management**: Static file serving with Vite build optimization

## External Dependencies

### Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching
- **express**: Node.js web framework for the backend API
- **drizzle-orm**: Type-safe SQL query builder and ORM
- **@neondatabase/serverless**: Serverless PostgreSQL client for Neon
- **wouter**: Lightweight client-side routing library

### UI and Styling Dependencies
- **@radix-ui/react-***: Headless UI component primitives (40+ components)
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Utility for creating component variants
- **clsx**: Conditional CSS class name utility
- **lucide-react**: Icon library for consistent iconography

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **@vitejs/plugin-react**: React support for Vite
- **drizzle-kit**: Database migration and introspection tools
- **esbuild**: Fast JavaScript bundler for production builds

### Database and Validation
- **zod**: Schema validation library
- **drizzle-zod**: Integration between Drizzle and Zod for schema validation
- **connect-pg-simple**: PostgreSQL session store (for future session management)

### Utility Libraries
- **date-fns**: Date manipulation and formatting
- **@hookform/resolvers**: Form validation resolvers for React Hook Form
- **nanoid**: URL-safe unique ID generator
- **cmdk**: Command palette component for enhanced UX
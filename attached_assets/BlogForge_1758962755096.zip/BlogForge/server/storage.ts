import { blogPosts, users, type BlogPost, type InsertBlogPost, type User, type UpsertUser } from "@shared/schema";
import { db } from "./db";
import { eq, ilike, desc, asc, and, sql, arrayContains } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Blog post methods
  getBlogPosts(params: {
    page?: number;
    limit?: number;
    search?: string;
    tags?: string[];
  }): Promise<{ posts: BlogPost[]; total: number }>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  getBlogPostById(id: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: string, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined>;
  deleteBlogPost(id: string): Promise<boolean>;
  incrementViews(id: string): Promise<void>;
  getAllTags(): Promise<string[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: sql`now()`,
        },
      })
      .returning();
    return user;
  }

  async getBlogPosts(params: {
    page?: number;
    limit?: number;
    search?: string;
    tags?: string[];
  }): Promise<{ posts: BlogPost[]; total: number }> {
    const { page = 1, limit = 6, search, tags = [] } = params;
    const offset = (page - 1) * limit;
    
    let query = db.select().from(blogPosts);
    let countQuery = db.select({ count: sql<number>`count(*)` }).from(blogPosts);
    
    const conditions = [];
    
    if (search) {
      conditions.push(ilike(blogPosts.title, `%${search}%`));
    }
    
    if (tags.length > 0) {
      for (const tag of tags) {
        conditions.push(arrayContains(blogPosts.tags, [tag]));
      }
    }
    
    if (conditions.length > 0) {
      const whereClause = conditions.length === 1 ? conditions[0] : and(...conditions);
      query = query.where(whereClause) as any;
      countQuery = countQuery.where(whereClause) as any;
    }
    
    const [posts, totalResult] = await Promise.all([
      query
        .orderBy(desc(blogPosts.publishDate))
        .limit(limit)
        .offset(offset),
      countQuery
    ]);
    
    return {
      posts,
      total: totalResult[0]?.count || 0
    };
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return post || undefined;
  }

  async getBlogPostById(id: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post || undefined;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [newPost] = await db
      .insert(blogPosts)
      .values({
        ...post,
        updatedAt: sql`now()`
      })
      .returning();
    return newPost;
  }

  async updateBlogPost(id: string, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
    const [updatedPost] = await db
      .update(blogPosts)
      .set({
        ...post,
        updatedAt: sql`now()`
      })
      .where(eq(blogPosts.id, id))
      .returning();
    return updatedPost || undefined;
  }

  async deleteBlogPost(id: string): Promise<boolean> {
    const result = await db.delete(blogPosts).where(eq(blogPosts.id, id));
    return (result.rowCount || 0) > 0;
  }

  async incrementViews(id: string): Promise<void> {
    await db
      .update(blogPosts)
      .set({
        views: sql`${blogPosts.views} + 1`
      })
      .where(eq(blogPosts.id, id));
  }

  async getAllTags(): Promise<string[]> {
    const result = await db
      .select({ tags: blogPosts.tags })
      .from(blogPosts)
      .where(sql`array_length(${blogPosts.tags}, 1) > 0`);
    
    const allTags = new Set<string>();
    result.forEach(row => {
      if (row.tags) {
        row.tags.forEach(tag => allTags.add(tag));
      }
    });
    
    return Array.from(allTags).sort();
  }
}

export const storage = new DatabaseStorage();
